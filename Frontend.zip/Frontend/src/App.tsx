import { useMemo, useState } from "react"

type IconName = "home" | "map" | "tractor" | "truck" | "box" | "wheat" | "file" | "invoice" | "scan" | "wallet" | "cheque" | "ledger" | "chart" | "users" | "search" | "bell" | "menu" | "plus" | "download" | "filter" | "more" | "arrow" | "calendar" | "check" | "warning" | "close" | "upload" | "eye" | "logout"

function Icon({ name, size = 18 }: { name: IconName size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    home: (
      <>
        <path d="m3 10 9-7 9 7" />
        <path d="M5 9v11h14V9M9 20v-7h6v7" />
      </>
    ),
    map: (
      <>
        <path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3Z" />
        <path d="M9 3v15M15 6v15" />
      </>
    ),
    tractor: (
      <>
        <path d="M4 15h10l-2-5H7V5h5M14 12h3l2 3" />
        <circle cx="6" cy="17" r="3" />
        <circle cx="17" cy="17" r="2" />
        <path d="M8 7h5" />
      </>
    ),
    truck: (
      <>
        <path d="M3 6h11v11H3zM14 10h4l3 3v4h-7z" />
        <circle cx="7" cy="18" r="2" />
        <circle cx="18" cy="18" r="2" />
      </>
    ),
    box: (
      <>
        <path d="m4 7 8-4 8 4v10l-8 4-8-4Z" />
        <path d="m4 7 8 4 8-4M12 11v10" />
      </>
    ),
    wheat: (
      <>
        <path d="M12 21V8M8 5c2 0 4 2 4 4-2 0-4-2-4-4ZM16 3c-2 0-4 2-4 4 2 0 4-2 4-4ZM7 10c3 0 5 2 5 5-3 0-5-2-5-5ZM17 9c-3 0-5 2-5 5 3 0 5-2 5-5Z" />
      </>
    ),
    file: (
      <>
        <path d="M6 2h8l4 4v16H6z" />
        <path d="M14 2v5h5M9 12h6M9 16h6" />
      </>
    ),
    invoice: (
      <>
        <path d="M6 2h12v20l-3-2-3 2-3-2-3 2Z" />
        <path d="M9 8h6M9 12h6M9 16h3" />
      </>
    ),
    scan: (
      <>
        <path d="M3 8V4h4M17 4h4v4M21 16v4h-4M7 20H3v-4" />
        <path d="M7 9h10v7H7zM9 6h6" />
      </>
    ),
    wallet: (
      <>
        <path d="M3 6h16v14H3z" />
        <path d="M3 9h16M15 13h6v4h-6z" />
      </>
    ),
    cheque: (
      <>
        <path d="M3 5h18v14H3zM3 9h18" />
        <path d="M7 14h4M15 14h2" />
      </>
    ),
    ledger: (
      <>
        <path d="M5 3h14v18H5zM9 3v18M12 8h4M12 12h4M12 16h3" />
      </>
    ),
    chart: (
      <>
        <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" />
      </>
    ),
    users: (
      <>
        <circle cx="9" cy="8" r="3" />
        <path d="M3 20v-2c0-3 3-5 6-5s6 2 6 5v2M16 5a3 3 0 0 1 0 6M17 14c2 0 4 2 4 4v2" />
      </>
    ),
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-4-4" />
      </>
    ),
    bell: (
      <>
        <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" />
      </>
    ),
    menu: (
      <>
        <path d="M4 6h16M4 12h16M4 18h16" />
      </>
    ),
    plus: (
      <>
        <path d="M12 5v14M5 12h14" />
      </>
    ),
    download: (
      <>
        <path d="M12 3v12M7 10l5 5 5-5M4 21h16" />
      </>
    ),
    filter: (
      <>
        <path d="M3 5h18M6 12h12M10 19h4" />
      </>
    ),
    more: (
      <>
        <circle cx="5" cy="12" r="1" />
        <circle cx="12" cy="12" r="1" />
        <circle cx="19" cy="12" r="1" />
      </>
    ),
    arrow: (
      <>
        <path d="m9 18 6-6-6-6" />
      </>
    ),
    calendar: (
      <>
        <path d="M4 5h16v16H4zM8 3v4M16 3v4M4 10h16" />
      </>
    ),
    check: (
      <>
        <path d="m5 12 4 4L19 6" />
      </>
    ),
    warning: (
      <>
        <path d="M12 3 2 21h20ZM12 9v5M12 18h.01" />
      </>
    ),
    close: (
      <>
        <path d="m5 5 14 14M19 5 5 19" />
      </>
    ),
    upload: (
      <>
        <path d="M12 16V3M7 8l5-5 5 5M4 21h16" />
      </>
    ),
    eye: (
      <>
        <path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z" />
        <circle cx="12" cy="12" r="3" />
      </>
    ),
    logout: (
      <>
        <path d="M10 4H4v16h6M14 8l4 4-4 4M8 12h10" />
      </>
    ),
  }
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  )
}

type NavItem = { id: string label: string icon: IconName group: string }
const navItems: NavItem[] = [
  { id: "dashboard", label: "Inicio", icon: "home", group: "GENERAL" },
  {
    id: "campos",
    label: "Campos y campañas",
    icon: "map",
    group: "OPERACIONES",
  },
  {
    id: "servicios",
    label: "Servicios agropecuarios",
    icon: "tractor",
    group: "OPERACIONES",
  },
  {
    id: "cosechas",
    label: "Cosechas y entregas",
    icon: "truck",
    group: "OPERACIONES",
  },
  {
    id: "insumos",
    label: "Inventario de insumos",
    icon: "box",
    group: "STOCK",
  },
  { id: "cereal", label: "Stock de cereal", icon: "wheat", group: "STOCK" },
  { id: "remitos", label: "Remitos", icon: "file", group: "ADMINISTRACIÓN" },
  {
    id: "facturas",
    label: "Facturación",
    icon: "invoice",
    group: "ADMINISTRACIÓN",
  },
  {
    id: "documentos",
    label: "Procesar documentos",
    icon: "scan",
    group: "ADMINISTRACIÓN",
  },
  {
    id: "pagos",
    label: "Pagos y cobranzas",
    icon: "wallet",
    group: "FINANZAS",
  },
  {
    id: "cheques",
    label: "Gestión de cheques",
    icon: "cheque",
    group: "FINANZAS",
  },
  {
    id: "cuentas",
    label: "Cuentas corrientes",
    icon: "ledger",
    group: "FINANZAS",
  },
  {
    id: "informes",
    label: "Informes y reportes",
    icon: "chart",
    group: "SISTEMA",
  },
  {
    id: "usuarios",
    label: "Usuarios y permisos",
    icon: "users",
    group: "SISTEMA",
  },
]

const money = (value: number) =>
  new Intl.NumberFormat("es-AR", {
    style: "currency",
    currency: "ARS",
    maximumFractionDigits: 0,
  }).format(value)

function Badge({
  tone = "neutral",
  children,
}: {
  tone?: "success" | "danger" | "warning" | "neutral" | "info"
  children: React.ReactNode
}) {
  return (
    <span className={`badge ${tone}`}>
      <span className="badge-dot" />
      {children}
    </span>
  )
}

function Button({
  children,
  variant = "primary",
  icon,
  onClick,
}: {
  children: React.ReactNode
  variant?: "primary" | "secondary" | "danger" | "ghost"
  icon?: IconName
  onClick?: () => void
}) {
  return (
    <button className={`btn ${variant}`} onClick={onClick}>
      {icon && <Icon name={icon} size={16} />}
      {children}
    </button>
  )
}

function PageHeader({
  eyebrow,
  title,
  subtitle,
  action,
  onAction,
}: {
  eyebrow?: string
  title: string
  subtitle: string
  action?: string
  onAction?: () => void
}) {
  return (
    <div className="page-heading">
      <div>
        {eyebrow && <div className="eyebrow">{eyebrow}</div>}
        <h1>{title}</h1>
        <p>{subtitle}</p>
      </div>
      {action && (
        <Button icon="plus" onClick={onAction}>
          {action}
        </Button>
      )}
    </div>
  )
}

function Filters({
  search = "Buscar por nombre, número o CUIT...",
  extra = true,
}: {
  search?: string
  extra?: boolean
}) {
  return (
    <div className="filterbar">
      <label className="field-search">
        <Icon name="search" size={16} />
        <input placeholder={search} />
      </label>
      {extra && (
        <>
          <button className="selectlike">
            Estado: Todos <span>⌄</span>
          </button>
          <button className="selectlike">
            <Icon name="calendar" size={15} /> Últimos 30 días <span>⌄</span>
          </button>
        </>
      )}
      <button className="filter-button">
        <Icon name="filter" size={16} /> Más filtros{" "}
        <span className="filter-count">2</span>
      </button>
    </div>
  )
}

const activities = [
  [
    "Factura registrada",
    "Agroinsumos del Centro S.A.",
    "$ 2.845.300",
    "Hace 18 min",
    "invoice",
  ],
  [
    "Entrega confirmada",
    "Maíz · 28,4 tn · Carta Porte 8391",
    "Planta San Martín",
    "Hace 1 h",
    "truck",
  ],
  [
    "Pago aplicado",
    "Cooperativa Agrícola Unión",
    "$ 1.280.000",
    "Hace 3 h",
    "wallet",
  ],
  [
    "Stock actualizado",
    "Glifosato 66% · salida 240 l",
    "Depósito Norte",
    "Ayer, 16:42",
    "box",
  ],
] as const

function Dashboard({ onNavigate }: { onNavigate: (id: string) => void }) {
  return (
    <div className="content">
      <PageHeader
        title="Resumen general"
        subtitle="Situación consolidada de Establecimiento Los Aromos · Campaña 2025/2026"
      />
      <div className="context-strip">
        <div>
          <span>Empresa activa</span>
          <strong>Establecimiento Los Aromos S.A.</strong>
        </div>
        <div>
          <span>Campaña actual</span>
          <strong>2025/2026</strong>
        </div>
        <div>
          <span>Última actualización</span>
          <strong>Hoy, 10:42</strong>
        </div>
        <button>
          Administrar empresa <Icon name="arrow" size={14} />
        </button>
      </div>
      <section className="financial-overview">
        <div className="section-head">
          <div>
            <h2>Posición financiera</h2>
            <p>Valores acumulados del período en curso</p>
          </div>
          <button
            className="text-action"
            onClick={() => onNavigate("informes")}
          >
            Ver informe financiero <Icon name="arrow" size={14} />
          </button>
        </div>
        <div className="metric-row">
          <div className="metric">
            <span>Ingresos del mes</span>
            <strong>{money(18450200)}</strong>
            <small className="positive">↑ 8,4% vs. mes anterior</small>
          </div>
          <div className="metric">
            <span>Egresos del mes</span>
            <strong>{money(12380800)}</strong>
            <small>62% costos operativos</small>
          </div>
          <div className="metric">
            <span>Por cobrar</span>
            <strong>{money(9240600)}</strong>
            <small className="warning-text">3 comprobantes vencidos</small>
          </div>
          <div className="metric">
            <span>Por pagar</span>
            <strong>{money(6834200)}</strong>
            <small>Próx. vencimiento: 18/06</small>
          </div>
        </div>
      </section>
      <div className="dashboard-grid">
        <section className="panel cash-panel">
          <div className="section-head">
            <div>
              <h2>Flujo de fondos</h2>
              <p>Ingresos y egresos de los últimos 6 meses</p>
            </div>
            <button className="selectlike compact">
              6 meses <span>⌄</span>
            </button>
          </div>
          <div className="chart-legend">
            <span>
              <i className="income" />
              Ingresos
            </span>
            <span>
              <i className="expense" />
              Egresos
            </span>
          </div>
          <div className="bar-chart">
            {[
              ["ENE", 54, 41],
              ["FEB", 65, 48],
              ["MAR", 57, 52],
              ["ABR", 78, 55],
              ["MAY", 68, 61],
              ["JUN", 86, 58],
            ].map(([m, a, b]) => (
              <div className="bar-set" key={m}>
                <div className="bars">
                  <i className="income" style={{ height: `${a}%` }} />
                  <i className="expense" style={{ height: `${b}%` }} />
                </div>
                <span>{m}</span>
              </div>
            ))}
          </div>
        </section>
        <section className="panel due-panel">
          <div className="section-head">
            <div>
              <h2>Próximos vencimientos</h2>
              <p>Obligaciones de los próximos 10 días</p>
            </div>
            <span className="count-badge">5 pendientes</span>
          </div>
          {[
            [
              "18 JUN",
              "Agroinsumos del Centro S.A.",
              "Factura A 0004-001829",
              1280000,
              "danger",
            ],
            [
              "20 JUN",
              "Transporte El Resero S.R.L.",
              "Factura B 0003-000882",
              684500,
              "warning",
            ],
            ["24 JUN", "YPF Agro", "Factura A 0082-048311", 936200, "neutral"],
          ].map(([d, n, desc, val, tone]) => (
            <div className="due-row" key={String(desc)}>
              <div className="date-box">
                <b>{String(d).split(" ")[0]}</b>
                <span>JUN</span>
              </div>
              <div>
                <strong>{n}</strong>
                <span>{desc}</span>
              </div>
              <div className="due-value">
                <b>{money(Number(val))}</b>
                <Badge tone={tone as "danger" | "warning" | "neutral"}>
                  {tone === "danger"
                    ? "Vence pronto"
                    : tone === "warning"
                      ? "Pendiente"
                      : "Programado"}
                </Badge>
              </div>
            </div>
          ))}
          <button className="full-link" onClick={() => onNavigate("pagos")}>
            Ver todos los vencimientos <Icon name="arrow" size={14} />
          </button>
        </section>
        <section className="panel stock-summary">
          <div className="section-head">
            <div>
              <h2>Existencias y campaña</h2>
              <p>Resumen operativo actualizado</p>
            </div>
            <button className="icon-button">
              <Icon name="more" />
            </button>
          </div>
          <div className="stock-block">
            <div className="stock-icon">
              <Icon name="wheat" />
            </div>
            <div>
              <span>Stock total de cereal</span>
              <strong>3.842,6 tn</strong>
            </div>
            <div className="stock-parts">
              <span>
                <i style={{ width: "72%" }} />
                Disponible <b>2.784 tn</b>
              </span>
              <span>
                <i className="committed" style={{ width: "28%" }} />
                Comprometido <b>1.058,6 tn</b>
              </span>
            </div>
          </div>
          <div className="crop-grid">
            <div>
              <span>Soja</span>
              <strong>1.824 tn</strong>
              <small>47,5% del total</small>
            </div>
            <div>
              <span>Maíz</span>
              <strong>1.236 tn</strong>
              <small>32,2% del total</small>
            </div>
            <div>
              <span>Trigo</span>
              <strong>782,6 tn</strong>
              <small>20,3% del total</small>
            </div>
          </div>
          <div className="campaign-line">
            <div>
              <span>Superficie implantada</span>
              <strong>1.842 ha</strong>
            </div>
            <div>
              <span>Avance de cosecha</span>
              <strong>68%</strong>
            </div>
            <div className="progress">
              <i style={{ width: "68%" }} />
            </div>
          </div>
        </section>
        <section className="panel recent-panel">
          <div className="section-head">
            <div>
              <h2>Actividad reciente</h2>
              <p>Últimos movimientos registrados</p>
            </div>
            <button className="text-action">Ver historial</button>
          </div>
          {activities.map(([title, desc, value, time, icon]) => (
            <div className="activity" key={title}>
              <div className="activity-icon">
                <Icon name={icon} />
              </div>
              <div>
                <strong>{title}</strong>
                <span>{desc}</span>
              </div>
              <div>
                <b>{value}</b>
                <span>{time}</span>
              </div>
            </div>
          ))}
        </section>
      </div>
    </div>
  )
}

const invoiceRows = [
  [
    "FAC-A 0004-001829",
    "12/06/2026",
    "Agroinsumos del Centro S.A.",
    "30-71284564-9",
    "Compra de fertilizantes",
    2845300,
    "Pendiente",
  ],
  [
    "FAC-A 0082-048311",
    "10/06/2026",
    "YPF Agro",
    "30-54668997-8",
    "Combustible y lubricantes",
    936200,
    "Pendiente",
  ],
  [
    "FAC-B 0003-000882",
    "08/06/2026",
    "Transporte El Resero S.R.L.",
    "30-71884920-1",
    "Fletes de cereal",
    684500,
    "Vencida",
  ],
  [
    "FAC-A 0021-008423",
    "04/06/2026",
    "Semillas Pampeanas S.A.",
    "30-69874532-2",
    "Semilla de trigo",
    1924800,
    "Pagada",
  ],
  [
    "FAC-C 0014-000293",
    "29/05/2026",
    "Taller Don Abel",
    "20-22456890-7",
    "Reparación de maquinaria",
    378000,
    "Parcial",
  ],
  [
    "FAC-A 0053-002184",
    "26/05/2026",
    "Cooperativa Agrícola Unión",
    "30-52234567-1",
    "Servicios de acopio",
    1140600,
    "Pagada",
  ],
]

function Invoices({
  onNew,
  onSelect,
}: {
  onNew: () => void
  onSelect: (name: string) => void
}) {
  const [tab, setTab] = useState("Recibidas")
  return (
    <div className="content">
      <PageHeader
        eyebrow="ADMINISTRACIÓN"
        title="Facturación"
        subtitle="Gestión de comprobantes recibidos y emitidos"
        action="Nueva factura"
        onAction={onNew}
      />
      <div className="summary-line">
        <div>
          <span>Total del período</span>
          <strong>{money(16842500)}</strong>
          <small>38 comprobantes</small>
        </div>
        <div>
          <span>Pendiente de pago</span>
          <strong>{money(4982400)}</strong>
          <small>9 comprobantes</small>
        </div>
        <div>
          <span>Vencido</span>
          <strong className="danger-text">{money(1254300)}</strong>
          <small>3 comprobantes</small>
        </div>
        <div>
          <span>Crédito fiscal IVA</span>
          <strong>{money(2380400)}</strong>
          <small>Período junio 2026</small>
        </div>
      </div>
      <div className="table-panel">
        <div className="tabs">
          <button
            className={tab === "Recibidas" ? "active" : ""}
            onClick={() => setTab("Recibidas")}
          >
            Facturas recibidas <span>26</span>
          </button>
          <button
            className={tab === "Emitidas" ? "active" : ""}
            onClick={() => setTab("Emitidas")}
          >
            Facturas emitidas <span>12</span>
          </button>
        </div>
        <Filters search="Buscar por comprobante, proveedor o CUIT..." />
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>COMPROBANTE</th>
                <th>FECHA</th>
                <th>PROVEEDOR / RAZÓN SOCIAL</th>
                <th>CUIT</th>
                <th>CONCEPTO</th>
                <th className="right">TOTAL</th>
                <th>ESTADO</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {invoiceRows.map((r) => (
                <tr key={String(r[0])} onClick={() => onSelect(String(r[0]))}>
                  <td>
                    <strong>{r[0]}</strong>
                  </td>
                  <td>{r[1]}</td>
                  <td>
                    <strong className="regular">{r[2]}</strong>
                  </td>
                  <td className="mono">{r[3]}</td>
                  <td className="muted-cell">{r[4]}</td>
                  <td className="right amount">{money(Number(r[5]))}</td>
                  <td>
                    <Badge
                      tone={
                        r[6] === "Pagada"
                          ? "success"
                          : r[6] === "Vencida"
                            ? "danger"
                            : r[6] === "Parcial"
                              ? "info"
                              : "warning"
                      }
                    >
                      {r[6]}
                    </Badge>
                  </td>
                  <td>
                    <button className="icon-button">
                      <Icon name="more" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Pagination total="Mostrando 1–6 de 26 comprobantes" />
      </div>
    </div>
  )
}

function Harvest({ onNew }: { onNew: () => void }) {
  const rows = [
    [
      "15/06/2026",
      "Los Aromos · Lote 04",
      "Soja",
      "AC 482 QZ",
      "Transporte El Resero",
      "28.420 kg",
      "ACA Pergamino",
      "Entregada",
    ],
    [
      "15/06/2026",
      "La Esperanza · Lote 02",
      "Maíz",
      "AF 129 KL",
      "Logística Norte",
      "31.880 kg",
      "Planta San Martín",
      "En tránsito",
    ],
    [
      "14/06/2026",
      "Los Aromos · Lote 07",
      "Soja",
      "AE 743 RT",
      "Hnos. Molina",
      "29.140 kg",
      "Coop. Agrícola Unión",
      "Entregada",
    ],
    [
      "14/06/2026",
      "El Ombú · Lote 01",
      "Trigo",
      "AD 092 NV",
      "Transporte El Resero",
      "27.960 kg",
      "Molinos del Plata",
      "Observada",
    ],
    [
      "13/06/2026",
      "La Esperanza · Lote 06",
      "Maíz",
      "AG 381 CW",
      "Fletes Güemes",
      "32.200 kg",
      "Planta San Martín",
      "Entregada",
    ],
  ]
  return (
    <div className="content">
      <PageHeader
        eyebrow="OPERACIONES"
        title="Cosechas, cargas y entregas"
        subtitle="Seguimiento operativo de movimientos de cereal · Campaña 2025/2026"
        action="Registrar carga"
        onAction={onNew}
      />
      <div className="operation-band">
        <div>
          <span>Cargas este mes</span>
          <strong>148</strong>
        </div>
        <div>
          <span>Volumen transportado</span>
          <strong>4.326,8 tn</strong>
        </div>
        <div>
          <span>En tránsito</span>
          <strong>5 cargas</strong>
        </div>
        <div>
          <span>Con observaciones</span>
          <strong className="warning-text">2 cargas</strong>
        </div>
        <div className="band-action">
          <Icon name="truck" size={30} />
          <span>
            Última carga registrada<strong>Hoy, 09:48</strong>
          </span>
        </div>
      </div>
      <div className="table-panel">
        <Filters search="Buscar patente, transportista o destino..." />
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>FECHA</th>
                <th>ORIGEN</th>
                <th>CULTIVO</th>
                <th>PATENTE</th>
                <th>TRANSPORTISTA</th>
                <th className="right">CANTIDAD</th>
                <th>DESTINO</th>
                <th>ESTADO</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r[3]}>
                  <td>{r[0]}</td>
                  <td>
                    <strong>{r[1]}</strong>
                    <small>Campaña 2025/2026</small>
                  </td>
                  <td>
                    <span className={`crop-dot ${r[2].toLowerCase()}`} />
                    {r[2]}
                  </td>
                  <td>
                    <span className="plate">{r[3]}</span>
                  </td>
                  <td>{r[4]}</td>
                  <td className="right amount">{r[5]}</td>
                  <td>{r[6]}</td>
                  <td>
                    <Badge
                      tone={
                        r[7] === "Entregada"
                          ? "success"
                          : r[7] === "Observada"
                            ? "danger"
                            : "info"
                      }
                    >
                      {r[7]}
                    </Badge>
                  </td>
                  <td>
                    <button className="icon-button">
                      <Icon name="more" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Pagination total="Mostrando 1–5 de 148 movimientos" />
      </div>
    </div>
  )
}

function Inventory({
  onNew,
  cereal = false,
}: {
  onNew: () => void
  cereal?: boolean
}) {
  const inputRows = [
    [
      "Glifosato 66%",
      "Agroquímicos",
      "Depósito Norte",
      "1.240 l",
      "400 l",
      "840 l",
      "Stock normal",
    ],
    [
      "Urea granulada",
      "Fertilizantes",
      "Galpón Principal",
      "8.450 kg",
      "2.000 kg",
      "6.450 kg",
      "Stock normal",
    ],
    [
      "Semilla Soja DM 46i20",
      "Semillas",
      "Depósito Semillas",
      "32 bolsas",
      "—",
      "32 bolsas",
      "Stock bajo",
    ],
    [
      "Atrazina 90% WG",
      "Agroquímicos",
      "Depósito Norte",
      "180 kg",
      "80 kg",
      "100 kg",
      "Reponer",
    ],
    [
      "Semilla Maíz DK 72-10",
      "Semillas",
      "Depósito Semillas",
      "64 bolsas",
      "16 bolsas",
      "48 bolsas",
      "Stock normal",
    ],
  ]
  const cerealRows = [
    [
      "Soja",
      "2025/2026",
      "Los Aromos",
      "Silo 01",
      "1.824,0 tn",
      "426,0 tn",
      "1.398,0 tn",
      "Disponible",
    ],
    [
      "Maíz",
      "2025/2026",
      "La Esperanza",
      "Silo Bolsa 08",
      "1.236,0 tn",
      "512,0 tn",
      "724,0 tn",
      "Parcial",
    ],
    [
      "Trigo",
      "2025/2026",
      "El Ombú",
      "Coop. Agrícola Unión",
      "782,6 tn",
      "120,0 tn",
      "662,6 tn",
      "Disponible",
    ],
    [
      "Girasol",
      "2024/2025",
      "Los Aromos",
      "Silo 03",
      "184,2 tn",
      "184,2 tn",
      "0 tn",
      "Comprometido",
    ],
  ]
  const rows = cereal ? cerealRows : inputRows
  return (
    <div className="content">
      <PageHeader
        eyebrow="STOCK"
        title={cereal ? "Stock de cereal" : "Inventario de insumos"}
        subtitle={
          cereal
            ? "Existencias disponibles, comprometidas y entregadas por ubicación"
            : "Control de existencias y trazabilidad de movimientos"
        }
        action={cereal ? "Registrar movimiento" : "Nuevo insumo"}
        onAction={onNew}
      />
      <div className="inventory-layout">
        <aside className="inventory-aside">
          <h3>{cereal ? "Resumen por cultivo" : "Estado del inventario"}</h3>
          <div className="donut">
            <div>
              <strong>{cereal ? "3.842" : "82%"}</strong>
              <span>{cereal ? "tn totales" : "salud stock"}</span>
            </div>
          </div>
          <ul>
            {cereal ? (
              <>
                <li>
                  <i className="green" />
                  Disponible <b>2.784 tn</b>
                </li>
                <li>
                  <i className="amber" />
                  Comprometido <b>1.058 tn</b>
                </li>
                <li>
                  <i className="gray" />
                  Entregado (mes) <b>842 tn</b>
                </li>
              </>
            ) : (
              <>
                <li>
                  <i className="green" />
                  Stock normal <b>42</b>
                </li>
                <li>
                  <i className="amber" />
                  Stock bajo <b>6</b>
                </li>
                <li>
                  <i className="red" />
                  Reponer urgente <b>2</b>
                </li>
              </>
            )}
          </ul>
          <button className="full-link">
            Ver historial de movimientos <Icon name="arrow" size={14} />
          </button>
        </aside>
        <div className="table-panel inventory-table">
          <Filters
            search={
              cereal
                ? "Buscar cultivo, campo o ubicación..."
                : "Buscar insumo, categoría o depósito..."
            }
            extra={false}
          />
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  {(cereal
                    ? [
                        "CULTIVO",
                        "CAMPAÑA",
                        "CAMPO",
                        "UBICACIÓN",
                        "EXISTENCIA",
                        "COMPROMETIDO",
                        "DISPONIBLE",
                        "ESTADO",
                      ]
                    : [
                        "INSUMO",
                        "CATEGORÍA",
                        "UBICACIÓN",
                        "EXISTENCIA",
                        "RESERVADO",
                        "DISPONIBLE",
                        "ESTADO",
                      ]
                  ).map((x) => (
                    <th key={x}>{x}</th>
                  ))}
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r[0]}>
                    {r.map((c, i) => (
                      <td key={i} className={i >= 3 && i <= 6 ? "amount" : ""}>
                        {i === 0 ? (
                          <strong>{c}</strong>
                        ) : i === r.length - 1 ? (
                          <Badge
                            tone={
                              String(c).includes("normal") || c === "Disponible"
                                ? "success"
                                : String(c).includes("bajo") || c === "Parcial"
                                  ? "warning"
                                  : "danger"
                            }
                          >
                            {c}
                          </Badge>
                        ) : (
                          c
                        )}
                      </td>
                    ))}
                    <td>
                      <button className="icon-button">
                        <Icon name="more" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination
            total={`Mostrando 1–${rows.length} de ${
              cereal ? "18 posiciones" : "50 insumos"
            }`}
          />
        </div>
      </div>
    </div>
  )
}

function Fields({ onNew }: { onNew: () => void }) {
  const [selected, setSelected] = useState(0)
  const fields = [
    {
      name: "Establecimiento Los Aromos",
      place: "Pergamino, Buenos Aires",
      ha: "1.280 ha",
      lots: 8,
      planted: "1.164 ha",
      progress: 78,
    },
    {
      name: "La Esperanza",
      place: "Rojas, Buenos Aires",
      ha: "840 ha",
      lots: 6,
      planted: "760 ha",
      progress: 61,
    },
    {
      name: "El Ombú",
      place: "Colón, Buenos Aires",
      ha: "465 ha",
      lots: 4,
      planted: "412 ha",
      progress: 84,
    },
  ]
  const f = fields[selected]
  return (
    <div className="content">
      <PageHeader
        eyebrow="OPERACIONES"
        title="Campos, lotes y campañas"
        subtitle="Administración territorial y planificación agrícola"
        action="Nuevo campo"
        onAction={onNew}
      />
      <div className="fields-layout">
        <div className="field-list">
          <div className="field-list-head">
            <strong>Establecimientos</strong>
            <span>3 campos · 2.585 ha</span>
          </div>
          {fields.map((x, i) => (
            <button
              key={x.name}
              className={`field-card ${selected === i ? "active" : ""}`}
              onClick={() => setSelected(i)}
            >
              <div className="field-thumb">
                <Icon name="map" size={24} />
              </div>
              <div>
                <strong>{x.name}</strong>
                <span>{x.place}</span>
                <small>
                  {x.ha} · {x.lots} lotes
                </small>
              </div>
              <Icon name="arrow" size={16} />
            </button>
          ))}
        </div>
        <section className="field-detail">
          <div className="field-hero">
            <div>
              <div className="eyebrow">FICHA DEL ESTABLECIMIENTO</div>
              <h2>{f.name}</h2>
              <p>{f.place} · Partida inmobiliaria 083-004821</p>
            </div>
            <Button variant="secondary">Editar información</Button>
          </div>
          <div className="field-stats">
            <div>
              <span>Superficie total</span>
              <strong>{f.ha}</strong>
            </div>
            <div>
              <span>Superficie implantada</span>
              <strong>{f.planted}</strong>
            </div>
            <div>
              <span>Lotes activos</span>
              <strong>{f.lots}</strong>
            </div>
            <div>
              <span>Avance cosecha</span>
              <strong>{f.progress}%</strong>
            </div>
          </div>
          <div className="detail-section-head">
            <div>
              <h3>Lotes y cultivos</h3>
              <p>Campaña agrícola 2025/2026</p>
            </div>
            <Button variant="secondary" icon="plus">
              Asociar lote
            </Button>
          </div>
          <div className="lot-grid">
            {[
              ["Lote 01", "Soja", "186 ha", "72%"],
              ["Lote 02", "Maíz", "224 ha", "58%"],
              ["Lote 03", "Trigo", "148 ha", "100%"],
              ["Lote 04", "Soja", "206 ha", "68%"],
              ["Lote 05", "Maíz", "192 ha", "44%"],
              ["Lote 06", "Girasol", "208 ha", "81%"],
            ].map((l) => (
              <div className="lot" key={l[0]}>
                <div>
                  <strong>{l[0]}</strong>
                  <Badge tone="success">{l[1]}</Badge>
                </div>
                <span>
                  Superficie <b>{l[2]}</b>
                </span>
                <span>
                  Avance de campaña <b>{l[3]}</b>
                </span>
                <div className="progress">
                  <i style={{ width: l[3] }} />
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}

function Accounts() {
  const rows = [
    [
      "15/06/2026",
      "Factura A 0004-001829",
      "Compra fertilizantes",
      "2.845.300,00",
      "—",
      "2.845.300,00",
    ],
    [
      "12/06/2026",
      "Pago OP-000284",
      "Transferencia Banco Nación",
      "—",
      "1.280.000,00",
      "1.565.300,00",
    ],
    [
      "08/06/2026",
      "Nota de crédito NC-0012",
      "Bonificación comercial",
      "—",
      "185.400,00",
      "1.379.900,00",
    ],
    [
      "02/06/2026",
      "Factura A 0004-001790",
      "Compra agroquímicos",
      "920.800,00",
      "—",
      "2.300.700,00",
    ],
    [
      "28/05/2026",
      "Pago OP-000271",
      "Cheque propio N° 008412",
      "—",
      "1.500.000,00",
      "800.700,00",
    ],
  ]
  return (
    <div className="content">
      <PageHeader
        eyebrow="FINANZAS"
        title="Cuentas corrientes"
        subtitle="Saldos y movimientos de clientes y proveedores"
      />
      <div className="account-selector">
        <div className="entity-mark">AC</div>
        <div>
          <span>PROVEEDOR SELECCIONADO</span>
          <strong>Agroinsumos del Centro S.A.</strong>
          <small>CUIT 30-71284564-9 · Cuenta abierta desde 04/2021</small>
        </div>
        <button className="selectlike">
          Cambiar cuenta <span>⌄</span>
        </button>
      </div>
      <div className="account-balance">
        <div>
          <span>Saldo actual</span>
          <strong>{money(800700)}</strong>
          <small>Saldo a pagar</small>
        </div>
        <div>
          <span>Crédito disponible</span>
          <strong>{money(4200000)}</strong>
          <small>Límite: {money(5000000)}</small>
        </div>
        <div>
          <span>Próximo vencimiento</span>
          <strong>18/06/2026</strong>
          <small>{money(800700)}</small>
        </div>
        <div className="account-actions">
          <Button variant="secondary" icon="download">
            Exportar extracto
          </Button>
          <Button icon="plus">Registrar pago</Button>
        </div>
      </div>
      <div className="ledger">
        <div className="ledger-head">
          <div>
            <h2>Extracto de movimientos</h2>
            <p>Período: 01/05/2026 al 15/06/2026</p>
          </div>
          <div className="ledger-legend">
            <span>
              <i className="debit" />
              Débitos
            </span>
            <span>
              <i className="credit" />
              Créditos
            </span>
          </div>
        </div>
        <table>
          <thead>
            <tr>
              <th>FECHA</th>
              <th>COMPROBANTE</th>
              <th>CONCEPTO</th>
              <th className="right">DÉBITO</th>
              <th className="right">CRÉDITO</th>
              <th className="right">SALDO</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={r[1]}>
                <td>{r[0]}</td>
                <td>
                  <strong>{r[1]}</strong>
                </td>
                <td>{r[2]}</td>
                <td className="right debit-value">
                  {r[3] !== "—" ? "$ " + r[3] : r[3]}
                </td>
                <td className="right credit-value">
                  {r[4] !== "—" ? "$ " + r[4] : r[4]}
                </td>
                <td className="right amount">$ {r[5]}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <td colSpan={3}>SALDOS DEL PERÍODO</td>
              <td className="right">$ 3.766.100,00</td>
              <td className="right">$ 2.965.400,00</td>
              <td className="right">$ 800.700,00</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  )
}

function DocumentAI() {
  const [processed, setProcessed] = useState(false)
  const [confirmed, setConfirmed] = useState(false)
  return (
    <div className="content document-page">
      <PageHeader
        eyebrow="ADMINISTRACIÓN"
        title="Procesamiento inteligente de documentos"
        subtitle="Extraé datos de facturas y remitos con asistencia de IA y validación humana"
      />
      <div className="human-alert">
        <Icon name="warning" size={19} />
        <div>
          <strong>Control humano obligatorio</strong>
          <span>
            La información extraída nunca se registra automáticamente. Deberás
            revisar y confirmar todos los datos antes de guardarlos.
          </span>
        </div>
      </div>
      <div className="stepper">
        {[
          "Cargar documento",
          "Procesar con IA",
          "Revisar datos",
          "Confirmar registro",
        ].map((x, i) => (
          <div
            className={`${
              processed ? (i < 3 ? "done" : "active") : i === 0 ? "active" : ""
            }`}
            key={x}
          >
            <i>
              {processed && i < 2 ? <Icon name="check" size={13} /> : i + 1}
            </i>
            <span>{x}</span>
          </div>
        ))}
      </div>
      {!processed ? (
        <div className="upload-workspace">
          <div className="upload-zone">
            <div className="upload-icon">
              <Icon name="upload" size={28} />
            </div>
            <h2>Arrastrá una factura o remito aquí</h2>
            <p>Admite archivos PDF de hasta 15 MB</p>
            <Button variant="secondary" onClick={() => setProcessed(true)}>
              Seleccionar archivo
            </Button>
            <span>o arrastrá el archivo desde tu computadora</span>
          </div>
          <aside>
            <h3>¿Cómo funciona?</h3>
            <ol>
              <li>
                <i>1</i>
                <div>
                  <strong>Cargá el documento</strong>
                  <span>Factura o remito en formato PDF.</span>
                </div>
              </li>
              <li>
                <i>2</i>
                <div>
                  <strong>La IA extrae los datos</strong>
                  <span>Identifica emisor, fechas, importes e ítems.</span>
                </div>
              </li>
              <li>
                <i>3</i>
                <div>
                  <strong>Revisá campo por campo</strong>
                  <span>Los datos dudosos se marcan para controlar.</span>
                </div>
              </li>
              <li>
                <i>4</i>
                <div>
                  <strong>Confirmá el registro</strong>
                  <span>Vos decidís cuándo guardar la información.</span>
                </div>
              </li>
            </ol>
          </aside>
        </div>
      ) : (
        <div className="review-workspace">
          <section className="pdf-preview">
            <div className="pdf-toolbar">
              <span>
                <Icon name="file" size={16} /> factura_agroinsumos_1829.pdf
              </span>
              <div>
                <button>−</button>
                <span>85%</span>
                <button>+</button>
              </div>
            </div>
            <div className="paper">
              <div className="fake-logo">
                AGROINSUMOS
                <br />
                <b>DEL CENTRO</b>
              </div>
              <h3>FACTURA A</h3>
              <p>Cod. 01 · N° 0004-001829</p>
              <hr />
              <div className="paper-grid">
                <span>Razón Social</span>
                <b>Establecimiento Los Aromos S.A.</b>
                <span>CUIT</span>
                <b>30-70882144-3</b>
                <span>Fecha</span>
                <b>12/06/2026</b>
              </div>
              <table>
                <tbody>
                  <tr>
                    <td>Urea granulada</td>
                    <td>8.000 kg</td>
                    <td>$ 2.351.487</td>
                  </tr>
                  <tr>
                    <td>IVA 21%</td>
                    <td></td>
                    <td>$ 493.813</td>
                  </tr>
                </tbody>
              </table>
              <strong className="paper-total">TOTAL $ 2.845.300</strong>
            </div>
          </section>
          <section className="extracted">
            <div className="extracted-head">
              <div>
                <h2>Datos extraídos</h2>
                <p>
                  Confianza general de lectura: <b>94%</b>
                </p>
              </div>
              <Badge tone="warning">2 campos a revisar</Badge>
            </div>
            <div className="form-grid">
              <label>
                Tipo de documento
                <select defaultValue="Factura A">
                  <option>Factura A</option>
                </select>
                <small className="confidence good">
                  <Icon name="check" size={12} /> 99% de confianza
                </small>
              </label>
              <label>
                Número de comprobante
                <input defaultValue="0004-001829" />
                <small className="confidence good">
                  <Icon name="check" size={12} /> 98% de confianza
                </small>
              </label>
              <label>
                CUIT del emisor
                <input defaultValue="30-71284564-9" />
                <small className="confidence good">
                  <Icon name="check" size={12} /> 97% de confianza
                </small>
              </label>
              <label>
                Razón social
                <input defaultValue="Agroinsumos del Centro S.A." />
                <small className="confidence good">
                  <Icon name="check" size={12} /> 96% de confianza
                </small>
              </label>
              <label>
                Fecha de emisión
                <input defaultValue="12/06/2026" />
                <small className="confidence warn">
                  <Icon name="warning" size={12} /> Revisar dato
                </small>
              </label>
              <label>
                Fecha de vencimiento
                <input className="needs-review" defaultValue="18/06/2026" />
                <small className="confidence warn">
                  <Icon name="warning" size={12} /> 71% de confianza
                </small>
              </label>
              <label>
                Importe neto
                <input defaultValue="$ 2.351.487,60" />
              </label>
              <label>
                IVA 21%
                <input defaultValue="$ 493.812,40" />
              </label>
              <label className="full">
                Importe total
                <input className="total-input" defaultValue="$ 2.845.300,00" />
              </label>
            </div>
            <div className="confirmation">
              <label>
                <input
                  type="checkbox"
                  checked={confirmed}
                  onChange={(e) => setConfirmed(e.target.checked)}
                />
                <span>
                  Revisé el documento original y confirmo que la información
                  ingresada es correcta.
                </span>
              </label>
            </div>
            <div className="form-actions">
              <Button variant="secondary" onClick={() => setProcessed(false)}>
                Cancelar
              </Button>
              <Button variant="secondary">Guardar borrador</Button>
              <Button
                icon="check"
                onClick={() => confirmed && alert("Documento confirmado")}
              >
                Confirmar y registrar
              </Button>
            </div>
          </section>
        </div>
      )}
    </div>
  )
}

const genericData: Record<string, {
  title: string
  eyebrow: string
  subtitle: string
  action: string
  stats: string[][]
  columns: string[]
  rows: string[][]
}> = {
  servicios: {
    title: "Servicios agropecuarios",
    eyebrow: "OPERACIONES",
    subtitle: "Planificación y control de labores propias y contratadas",
    action: "Nuevo servicio",
    stats: [
      ["Trabajos del mes", "24"],
      ["Costo acumulado", "$ 8.420.600"],
      ["En ejecución", "3"],
      ["Pendientes", "5"],
    ],
    columns: [
      "FECHA",
      "LABOR",
      "CAMPO / LOTE",
      "PROVEEDOR",
      "SUPERFICIE",
      "COSTO",
      "ESTADO",
    ],
    rows: [
      [
        "14/06/2026",
        "Pulverización",
        "Los Aromos · Lote 04",
        "Aplicaciones del Norte",
        "206 ha",
        "$ 824.000",
        "Finalizado",
      ],
      [
        "12/06/2026",
        "Fertilización",
        "La Esperanza · Lote 02",
        "Agroservicios Rojas",
        "224 ha",
        "$ 1.568.000",
        "Finalizado",
      ],
      [
        "10/06/2026",
        "Siembra",
        "El Ombú · Lote 03",
        "Equipo propio",
        "148 ha",
        "$ 592.000",
        "En ejecución",
      ],
      [
        "08/06/2026",
        "Labranza",
        "Los Aromos · Lote 07",
        "Contratista San José",
        "180 ha",
        "$ 486.000",
        "Pendiente",
      ],
    ],
  },
  remitos: {
    title: "Remitos",
    eyebrow: "ADMINISTRACIÓN",
    subtitle: "Comprobantes de compra, entrega y traslado",
    action: "Nuevo remito",
    stats: [
      ["Remitos del mes", "42"],
      ["Sin facturar", "8"],
      ["Con PDF adjunto", "36"],
      ["Observados", "2"],
    ],
    columns: [
      "NÚMERO",
      "FECHA",
      "TIPO",
      "PROVEEDOR / DESTINO",
      "REFERENCIA",
      "CANTIDAD",
      "ESTADO",
    ],
    rows: [
      [
        "R 0003-008421",
        "15/06/2026",
        "Entrega",
        "ACA Pergamino",
        "CP 8391",
        "28.420 kg",
        "Confirmado",
      ],
      [
        "R 0001-002983",
        "14/06/2026",
        "Compra",
        "YPF Agro",
        "FAC pendiente",
        "4.800 l",
        "Sin facturar",
      ],
      [
        "R 0008-001294",
        "12/06/2026",
        "Traslado",
        "Depósito Norte",
        "INT-0021",
        "240 l",
        "Confirmado",
      ],
      [
        "R 0002-009104",
        "10/06/2026",
        "Compra",
        "Semillas Pampeanas",
        "FAC-A 0021-008423",
        "64 bolsas",
        "Facturado",
      ],
    ],
  },
  pagos: {
    title: "Pagos y cobranzas",
    eyebrow: "FINANZAS",
    subtitle: "Aplicación de operaciones a facturas y cuentas corrientes",
    action: "Registrar operación",
    stats: [
      ["Pagos del mes", "$ 12.380.800"],
      ["Cobranzas del mes", "$ 18.450.200"],
      ["Pendiente de aplicar", "$ 420.000"],
      ["Operaciones", "38"],
    ],
    columns: [
      "FECHA",
      "OPERACIÓN",
      "TERCERO",
      "MEDIO",
      "COMPROBANTES",
      "IMPORTE",
      "ESTADO",
    ],
    rows: [
      [
        "15/06/2026",
        "OP-000284",
        "Agroinsumos del Centro",
        "Transferencia",
        "FAC-A 001829",
        "$ 1.280.000",
        "Aplicado",
      ],
      [
        "13/06/2026",
        "CO-000108",
        "Molinos del Plata",
        "Transferencia",
        "FAC-A 000382",
        "$ 3.840.000",
        "Aplicado",
      ],
      [
        "11/06/2026",
        "OP-000279",
        "YPF Agro",
        "Cheque propio",
        "2 facturas",
        "$ 936.200",
        "Pendiente",
      ],
      [
        "09/06/2026",
        "CO-000104",
        "Cooperativa Agrícola Unión",
        "Cheque tercero",
        "FAC-A 000374",
        "$ 2.120.000",
        "Aplicado",
      ],
    ],
  },
  cheques: {
    title: "Gestión de cheques",
    eyebrow: "FINANZAS",
    subtitle: "Cheques propios y de terceros · cartera y vencimientos",
    action: "Registrar cheque",
    stats: [
      ["En cartera", "$ 4.820.000"],
      ["A vencer (15 días)", "$ 1.640.000"],
      ["Depositados", "$ 2.185.000"],
      ["Rechazados", "1"],
    ],
    columns: [
      "NÚMERO",
      "BANCO",
      "TITULAR",
      "EMISIÓN",
      "VENCIMIENTO",
      "IMPORTE",
      "ESTADO",
    ],
    rows: [
      [
        "008412",
        "Banco Nación",
        "Los Aromos S.A.",
        "28/05/2026",
        "18/06/2026",
        "$ 1.500.000",
        "Entregado",
      ],
      [
        "193842",
        "Banco Provincia",
        "Molinos del Plata",
        "04/06/2026",
        "22/06/2026",
        "$ 2.120.000",
        "En cartera",
      ],
      [
        "004291",
        "Santander",
        "Coop. Agrícola Unión",
        "08/06/2026",
        "30/06/2026",
        "$ 1.280.000",
        "En cartera",
      ],
      [
        "281039",
        "Banco Galicia",
        "Cereales San Jorge",
        "01/06/2026",
        "12/06/2026",
        "$ 845.000",
        "Depositado",
      ],
    ],
  },
  usuarios: {
    title: "Usuarios y permisos",
    eyebrow: "SISTEMA",
    subtitle: "Administración de accesos, roles y actividad",
    action: "Nuevo usuario",
    stats: [
      ["Usuarios activos", "8"],
      ["Administradores", "2"],
      ["Encargados", "6"],
      ["Accesos hoy", "5"],
    ],
    columns: [
      "USUARIO",
      "CORREO",
      "ROL",
      "ÚLTIMO ACCESO",
      "MÓDULOS HABILITADOS",
      "ESTADO",
    ],
    rows: [
      [
        "Martín Roldán",
        "m.roldan@losaromos.com.ar",
        "Administrador",
        "Hoy, 10:42",
        "Todos",
        "Activo",
      ],
      [
        "Sofía Benítez",
        "s.benitez@losaromos.com.ar",
        "Administrador",
        "Hoy, 09:18",
        "Todos",
        "Activo",
      ],
      [
        "Lucas Ferreyra",
        "l.ferreyra@losaromos.com.ar",
        "Encargado",
        "Ayer, 18:04",
        "Operaciones · Stock",
        "Activo",
      ],
      [
        "Carolina Paz",
        "c.paz@losaromos.com.ar",
        "Encargado",
        "12/06/2026",
        "Facturación · Finanzas",
        "Activo",
      ],
    ],
  },
  informes: {
    title: "Informes y reportes",
    eyebrow: "SISTEMA",
    subtitle: "Análisis consolidado para gestión y auditoría",
    action: "Crear informe",
    stats: [
      ["Reportes disponibles", "12"],
      ["Generados este mes", "28"],
      ["Programados", "3"],
      ["Última exportación", "Hoy, 09:20"],
    ],
    columns: [
      "INFORME",
      "CATEGORÍA",
      "PERÍODO",
      "ÚLTIMA GENERACIÓN",
      "FORMATO",
      "ESTADO",
    ],
    rows: [
      [
        "Ingresos y egresos",
        "Finanzas",
        "Junio 2026",
        "Hoy, 09:20",
        "Excel · PDF",
        "Disponible",
      ],
      [
        "Costos por campaña",
        "Operaciones",
        "2025/2026",
        "14/06/2026",
        "Excel",
        "Disponible",
      ],
      [
        "Existencias de cereal",
        "Stock",
        "Al 15/06/2026",
        "15/06/2026",
        "PDF",
        "Disponible",
      ],
      [
        "Cuentas por pagar",
        "Finanzas",
        "Próximos 30 días",
        "12/06/2026",
        "Excel · PDF",
        "Programado",
      ],
    ],
  },
}

function GenericModule({ type, onNew }: { type: string onNew: () => void }) {
  const d = genericData[type]
  return (
    <div className="content">
      <PageHeader
        eyebrow={d.eyebrow}
        title={d.title}
        subtitle={d.subtitle}
        action={d.action}
        onAction={onNew}
      />
      <div className="summary-line compact-summary">
        {d.stats.map((x) => (
          <div key={x[0]}>
            <span>{x[0]}</span>
            <strong>{x[1]}</strong>
          </div>
        ))}
      </div>
      <div className="table-panel">
        <Filters />
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                {d.columns.map((c) => (
                  <th key={c}>{c}</th>
                ))}
                <th></th>
              </tr>
            </thead>
            <tbody>
              {d.rows.map((r, i) => (
                <tr key={i}>
                  {r.map((c, j) => (
                    <td key={j}>
                      {j === 0 ? (
                        <strong>{c}</strong>
                      ) : j === r.length - 1 ? (
                        <Badge
                          tone={
                            [
                              "Activo",
                              "Aplicado",
                              "Finalizado",
                              "Confirmado",
                              "Disponible",
                              "Depositado",
                            ].some((x) => c.includes(x))
                              ? "success"
                              : c.includes("Pendiente") ||
                                  c.includes("cartera") ||
                                  c.includes("facturar")
                                ? "warning"
                                : "info"
                          }
                        >
                          {c}
                        </Badge>
                      ) : (
                        c
                      )}
                    </td>
                  ))}
                  <td>
                    <button className="icon-button">
                      <Icon name="more" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Pagination
          total={`Mostrando 1–4 de ${
            type === "usuarios" ? "8" : "24"
          } registros`}
        />
      </div>
    </div>
  )
}

function Pagination({ total }: { total: string }) {
  return (
    <div className="pagination">
      <span>{total}</span>
      <div>
        <button disabled>‹</button>
        <button className="active">1</button>
        <button>2</button>
        <button>3</button>
        <button>›</button>
      </div>
    </div>
  )
}

function Modal({ title, onClose }: { title: string onClose: () => void }) {
  const [saved, setSaved] = useState(false)
  if (saved)
    return (
      <div className="modal-backdrop">
        <div className="success-modal">
          <div>
            <Icon name="check" size={28} />
          </div>
          <h2>Registro guardado</h2>
          <p>La información se incorporó correctamente al sistema.</p>
          <Button onClick={onClose}>Continuar</Button>
        </div>
      </div>
    )
  return (
    <div
      className="modal-backdrop"
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="modal">
        <div className="modal-head">
          <div>
            <span>NUEVO REGISTRO</span>
            <h2>{title}</h2>
          </div>
          <button onClick={onClose}>
            <Icon name="close" />
          </button>
        </div>
        <div className="modal-body">
          <div className="form-section">
            <h3>Información principal</h3>
            <div className="form-grid">
              <label>
                Fecha *<input type="text" defaultValue="15/06/2026" />
              </label>
              <label>
                Tipo de registro *
                <select>
                  <option>Seleccionar opción</option>
                  <option>Compra</option>
                  <option>Venta</option>
                </select>
              </label>
              <label className="full">
                Razón social / Descripción *
                <input placeholder="Ingresá una descripción" />
              </label>
              <label>
                Importe / Cantidad *<input placeholder="0,00" />
              </label>
              <label>
                Estado *
                <select>
                  <option>Pendiente</option>
                  <option>Confirmado</option>
                </select>
              </label>
              <label className="full">
                Observaciones
                <textarea placeholder="Información adicional (opcional)" />
              </label>
            </div>
          </div>
        </div>
        <div className="modal-foot">
          <span>* Campos obligatorios</span>
          <div>
            <Button variant="secondary" onClick={onClose}>
              Cancelar
            </Button>
            <Button onClick={() => setSaved(true)}>Guardar registro</Button>
          </div>
        </div>
      </div>
    </div>
  )
}

function DetailDrawer({ item, onClose }: { item: string onClose: () => void }) {
  return (
    <div
      className="drawer-backdrop"
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <aside className="drawer">
        <div className="drawer-head">
          <div>
            <span>DETALLE DE COMPROBANTE</span>
            <h2>{item}</h2>
          </div>
          <button onClick={onClose}>
            <Icon name="close" />
          </button>
        </div>
        <div className="drawer-status">
          <Badge tone="warning">Pendiente de pago</Badge>
          <span>Registrada el 12/06/2026 por Sofía Benítez</span>
        </div>
        <div className="drawer-body">
          <h3>Datos del proveedor</h3>
          <dl>
            <div>
              <dt>Razón social</dt>
              <dd>Agroinsumos del Centro S.A.</dd>
            </div>
            <div>
              <dt>CUIT</dt>
              <dd>30-71284564-9</dd>
            </div>
            <div>
              <dt>Fecha de emisión</dt>
              <dd>12/06/2026</dd>
            </div>
            <div>
              <dt>Vencimiento</dt>
              <dd className="danger-text">18/06/2026</dd>
            </div>
          </dl>
          <h3>Importes</h3>
          <dl>
            <div>
              <dt>Importe neto</dt>
              <dd>$ 2.351.487,60</dd>
            </div>
            <div>
              <dt>IVA 21%</dt>
              <dd>$ 493.812,40</dd>
            </div>
            <div className="drawer-total">
              <dt>Total</dt>
              <dd>$ 2.845.300,00</dd>
            </div>
          </dl>
          <h3>Documentación relacionada</h3>
          <button className="file-row">
            <Icon name="file" />
            <span>
              <strong>factura_agroinsumos_1829.pdf</strong>
              <small>PDF · 1,2 MB</small>
            </span>
            <Icon name="eye" />
          </button>
        </div>
        <div className="drawer-foot">
          <Button variant="secondary">Editar</Button>
          <Button>Registrar pago</Button>
        </div>
      </aside>
    </div>
  )
}

export default function App() {
  const [active, setActive] = useState("dashboard")
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [modal, setModal] = useState<string | null>(null)
  const [detail, setDetail] = useState<string | null>(null)
  const [notifications, setNotifications] = useState(false)
  const current = useMemo(
    () => navItems.find((n) => n.id === active)!,
    [active],
  )
  const groups = [...new Set(navItems.map((n) => n.group))]
  const navigate = (id: string) => {
    setActive(id)
    setMobileOpen(false)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }
  const render = () => {
    if (active === "dashboard") return <Dashboard onNavigate={navigate} />
    if (active === "facturas")
      return (
        <Invoices
          onNew={() => setModal("Nueva factura")}
          onSelect={setDetail}
        />
      )
    if (active === "cosechas")
      return <Harvest onNew={() => setModal("Registrar carga")} />
    if (active === "insumos")
      return <Inventory onNew={() => setModal("Nuevo insumo")} />
    if (active === "cereal")
      return <Inventory cereal onNew={() => setModal("Movimiento de cereal")} />
    if (active === "campos")
      return <Fields onNew={() => setModal("Nuevo campo")} />
    if (active === "cuentas") return <Accounts />
    if (active === "documentos") return <DocumentAI />
    return (
      <GenericModule
        type={active}
        onNew={() => setModal(genericData[active].action)}
      />
    )
  }
  return (
    <div className={`app-shell ${collapsed ? "sidebar-collapsed" : ""}`}>
      <aside className={`sidebar ${mobileOpen ? "mobile-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark">
            <Icon name="wheat" size={22} />
          </div>
          <div>
            <strong>AGROGESTIÓN</strong>
            <span>ERP Agropecuario</span>
          </div>
          <button className="mobile-close" onClick={() => setMobileOpen(false)}>
            <Icon name="close" />
          </button>
        </div>
        <nav>
          {groups.map((g) => (
            <div className="nav-group" key={g}>
              <span className="group-title">{g}</span>
              {navItems
                .filter((n) => n.group === g)
                .map((n) => (
                  <button
                    title={n.label}
                    className={active === n.id ? "active" : ""}
                    onClick={() => navigate(n.id)}
                    key={n.id}
                  >
                    <Icon name={n.icon} />
                    <span>{n.label}</span>
                    {active === n.id && <i />}
                  </button>
                ))}
            </div>
          ))}
        </nav>
        <div className="sidebar-user">
          <div>MR</div>
          <span>
            <strong>Martín Roldán</strong>
            <small>Administrador</small>
          </span>
          <button title="Cerrar sesión">
            <Icon name="logout" size={17} />
          </button>
        </div>
      </aside>
      {mobileOpen && (
        <div className="mobile-overlay" onClick={() => setMobileOpen(false)} />
      )}
      <main>
        <header className="topbar">
          <button
            className="collapse-button desktop-only"
            onClick={() => setCollapsed(!collapsed)}
          >
            <Icon name="menu" />
          </button>
          <button
            className="collapse-button mobile-only"
            onClick={() => setMobileOpen(true)}
          >
            <Icon name="menu" />
          </button>
          <div className="breadcrumb">
            <span>Agrogestión</span>
            <Icon name="arrow" size={13} />
            <strong>{current.label}</strong>
          </div>
          <label className="global-search">
            <Icon name="search" size={17} />
            <input placeholder="Buscar en todo el sistema..." />
            <kbd>⌘ K</kbd>
          </label>
          <div className="top-actions">
            <button
              className="notification-button"
              onClick={() => setNotifications(!notifications)}
            >
              <Icon name="bell" />
              <i />
            </button>
            <div className="top-user">
              <div>MR</div>
              <span>
                <strong>Martín Roldán</strong>
                <small>Administrador</small>
              </span>
              <b>⌄</b>
            </div>
          </div>
          {notifications && (
            <div className="notification-popover">
              <div>
                <strong>Notificaciones</strong>
                <button onClick={() => setNotifications(false)}>
                  <Icon name="close" size={16} />
                </button>
              </div>
              <article>
                <i className="critical">
                  <Icon name="warning" size={15} />
                </i>
                <span>
                  <strong>Factura próxima a vencer</strong>
                  <small>FAC-A 0004-001829 vence en 3 días.</small>
                </span>
              </article>
              <article>
                <i>
                  <Icon name="box" size={15} />
                </i>
                <span>
                  <strong>Stock por debajo del mínimo</strong>
                  <small>Semilla Soja DM 46i20 requiere reposición.</small>
                </span>
              </article>
              <button className="full-link">
                Ver todas las notificaciones
              </button>
            </div>
          )}
        </header>
        {render()}
      </main>
      {modal && <Modal title={modal} onClose={() => setModal(null)} />}
      {detail && <DetailDrawer item={detail} onClose={() => setDetail(null)} />}
    </div>
  )
}
